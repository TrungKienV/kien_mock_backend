package com.vti.vtira59backend.service.impl;

import com.vti.vtira59backend.modal.dto.ProductDto;
import com.vti.vtira59backend.modal.dto.UserDto;
import com.vti.vtira59backend.modal.entity.Product;
import com.vti.vtira59backend.modal.entity.Role;
import com.vti.vtira59backend.modal.entity.User;
import com.vti.vtira59backend.modal.request.CreateProductRequest;
import com.vti.vtira59backend.modal.request.CreateUserRequest;
import com.vti.vtira59backend.modal.request.UpdateProductRequest;
import com.vti.vtira59backend.modal.request.UpdateUserRequest;
import com.vti.vtira59backend.repository.UserRepository;
import com.vti.vtira59backend.service.IUserService;
import lombok.Data;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService implements IUserService {
    @Autowired
    private UserRepository repository;

    @Override
    public List<User> getAll() {

        return repository.findAll();
    }

    @Override
    public User getById(int id) {
        Optional<User> optional = repository.findById(id);
        if(optional.isPresent()){
            return optional.get();
        }
        return null;
    }

    @Override
    public void create(CreateUserRequest request) {
        User bUser = new User();

        BeanUtils.copyProperties(request, bUser);

        bUser.setRole(Role.USER);
        repository.save(bUser);



    }

    @Override
    public User update(UpdateUserRequest request) {
        Optional<User> optionalUser = repository.findById(request.getId());
        if (optionalUser.isPresent()){
            User user = optionalUser.get();
            BeanUtils.copyProperties(request,user);
            return repository.save(user);
        }
        return null;
    }

    @Override
    public void delete(int id) {
        repository.deleteById(id);
    }
}
