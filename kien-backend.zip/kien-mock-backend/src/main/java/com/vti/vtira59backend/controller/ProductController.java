package com.vti.vtira59backend.controller;

import com.vti.vtira59backend.modal.dto.ProductDto;

import com.vti.vtira59backend.modal.entity.Product;

import com.vti.vtira59backend.modal.request.CreateProductRequest;

import com.vti.vtira59backend.modal.request.UpdateProductRequest;

import com.vti.vtira59backend.service.impl.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/product")
@CrossOrigin("*")
public class ProductController {
    @Autowired
    private ProductService service;

    @GetMapping("/get-all")
    public List<Product> getAll(){
        return service.getAll();
    }

    @GetMapping("/{id}")
    public ProductDto getById(@PathVariable int id){
        return service.getById(id);
    }

    @PostMapping("/create")
    public void create(@RequestBody CreateProductRequest request){

        service.create(request);
    }

    @PutMapping("/update")
    public Product update(@RequestBody UpdateProductRequest request){
        return service.update(request);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable int id){
        service.delete(id);
    }
}
