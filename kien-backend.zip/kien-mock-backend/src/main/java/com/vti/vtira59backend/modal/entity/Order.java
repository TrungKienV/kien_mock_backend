package com.vti.vtira59backend.modal.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "`order`")
@Data
@NoArgsConstructor
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "final_price")
    private int finalPrice;

    @Column(name = "product_id")
    private int productId;

    @Column(name = "buyer_id")
    private int buyerId;

}
