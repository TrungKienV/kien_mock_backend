package com.vti.vtira59backend.modal.request;

import com.vti.vtira59backend.modal.entity.Role;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Data
public class CreateUserRequest {
    private Role role;

    private String firstName;

    private String lastName;

    private Date dateOfBirth;

    private String cccd;

    private String address;

    private String phoneNumber;

    private String bankCardNumber;

    private String username;

    private String password;
}
