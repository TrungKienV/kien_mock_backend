package com.vti.vtira59backend.service.impl;

import com.vti.vtira59backend.modal.dto.BidDto;
import com.vti.vtira59backend.modal.entity.Bid;
import com.vti.vtira59backend.modal.request.CreateBidRequest;
import com.vti.vtira59backend.modal.request.UpdateBidRequest;
import com.vti.vtira59backend.repository.BidRepository;
import com.vti.vtira59backend.service.IBidService;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.modelmapper.TypeMap;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class BidService implements IBidService {
    @Autowired
    private BidRepository bidRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<BidDto> getBidByProductId(int id) {
        List<Bid> bids = bidRepository.findByProductId(id);
        List<BidDto> bidDtos = modelMapper.map(bids, new TypeToken<List<BidDto>>() {
        }.getType());
        return bidDtos;
    }

    @Override
    public void createBid(CreateBidRequest form) {
        TypeMap<CreateBidRequest,Bid> typeMap = modelMapper.getTypeMap(CreateBidRequest.class, Bid.class);
        if(typeMap == null){
            modelMapper.addMappings(new PropertyMap<CreateBidRequest, Bid>() {
                @Override
                protected void configure() {
                    skip(destination.getId());
                }
            });

        Bid bid = modelMapper.map(form, Bid.class);
        bidRepository.save(bid);
        }
    }

    @Override
    public void deleteBid(int id) {
        bidRepository.deleteById(id);
    }

    @Override
    public void updateBid(UpdateBidRequest form) {
        if (form.getBidTime() == null){
            form.setBidTime(new Date());
        }
        Bid bid = modelMapper.map(form, Bid.class);
        bidRepository.save(bid);
    }
}
