package com.vti.vtira59backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VtiRa59BackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(VtiRa59BackendApplication.class, args);
    }

}
