package com.vti.vtira59backend.service;


import com.vti.vtira59backend.modal.dto.ProductDto;

import com.vti.vtira59backend.modal.entity.Product;

import com.vti.vtira59backend.modal.request.CreateProductRequest;

import com.vti.vtira59backend.modal.request.UpdateProductRequest;

import java.util.List;

public interface IProductService {
    List<Product> getAll();

    ProductDto getById(int id);

    void create(CreateProductRequest request);

    Product update(UpdateProductRequest request);

    void delete(int id);

}
