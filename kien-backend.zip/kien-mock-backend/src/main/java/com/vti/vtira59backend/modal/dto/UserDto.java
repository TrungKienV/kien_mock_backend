package com.vti.vtira59backend.modal.dto;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Data
public class UserDto {

    private int id;

    private String firstName;

    private String lastName;

    private Date dateOfBirth;

    private String cccd;

    private String address;

    private String phoneNumber;

    private String bankCardNumber;

    private String username;

    private String password;
}
