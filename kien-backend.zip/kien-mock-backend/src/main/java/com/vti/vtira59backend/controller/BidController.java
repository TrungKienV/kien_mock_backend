package com.vti.vtira59backend.controller;

import com.vti.vtira59backend.modal.dto.BidDto;
import com.vti.vtira59backend.modal.entity.Bid;
import com.vti.vtira59backend.modal.request.CreateBidRequest;
import com.vti.vtira59backend.modal.request.UpdateBidRequest;
import com.vti.vtira59backend.service.IBidService;
import com.vti.vtira59backend.service.impl.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("api/v1/bids")
@CrossOrigin("*")
public class BidController {
    @Autowired
    private IBidService service;

    @GetMapping("/product/{id}")
    public List<BidDto> getBidByProductId(@PathVariable int id){

        return service.getBidByProductId(id);
    }

    @PostMapping
    public void createBid(@RequestBody CreateBidRequest form){
        service.createBid(form);
    }

    @PutMapping("{id}")
    public void updateBid(@PathVariable int id, @RequestBody UpdateBidRequest form) {
        form.setId(id);
        service.updateBid(form);
    }

    @DeleteMapping("/{id}")
    public void deleteBid(@PathVariable int id){
        service.deleteBid(id);
    }
}
