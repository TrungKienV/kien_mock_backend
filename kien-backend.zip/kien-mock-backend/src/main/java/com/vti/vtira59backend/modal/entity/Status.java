package com.vti.vtira59backend.modal.entity;

public enum Status {
    CREATED, SOLD, CANCEL
}
