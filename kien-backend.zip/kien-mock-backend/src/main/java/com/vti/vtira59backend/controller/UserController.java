package com.vti.vtira59backend.controller;

import com.vti.vtira59backend.modal.dto.ProductDto;
import com.vti.vtira59backend.modal.entity.Product;
import com.vti.vtira59backend.modal.entity.User;
import com.vti.vtira59backend.modal.request.CreateProductRequest;
import com.vti.vtira59backend.modal.request.CreateUserRequest;
import com.vti.vtira59backend.modal.request.UpdateProductRequest;
import com.vti.vtira59backend.modal.request.UpdateUserRequest;
import com.vti.vtira59backend.service.impl.ProductService;
import com.vti.vtira59backend.service.impl.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/user")
@CrossOrigin("*")
public class UserController {
        @Autowired
        private UserService service;

        @GetMapping("/get-all")
        public List<User> getAll(){
            return service.getAll();
        }

        @GetMapping("/{id}")
        public User getById(@PathVariable int id){
            return service.getById(id);
        }

        @PostMapping("/create")
        public void create(@RequestBody CreateUserRequest request){

            service.create(request);
        }

        @PutMapping("/update")
        public User update(@RequestBody UpdateUserRequest request){
            return service.update(request);
        }

        @DeleteMapping("/{id}")
        public void delete(@PathVariable int id){
            service.delete(id);
        }
}
