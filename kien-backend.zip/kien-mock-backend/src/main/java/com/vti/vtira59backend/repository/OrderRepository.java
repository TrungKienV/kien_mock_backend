package com.vti.vtira59backend.repository;

import com.vti.vtira59backend.modal.entity.Bid;
import com.vti.vtira59backend.modal.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Integer> {
    @Query("SELECT d FROM Order d WHERE d.buyerId = :buyerId")
    List<Order> findByBuyerId(@Param("buyerId") int id);
}
