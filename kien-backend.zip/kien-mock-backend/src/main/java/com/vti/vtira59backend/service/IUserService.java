package com.vti.vtira59backend.service;

import com.vti.vtira59backend.modal.dto.ProductDto;
import com.vti.vtira59backend.modal.dto.UserDto;
import com.vti.vtira59backend.modal.entity.Product;
import com.vti.vtira59backend.modal.entity.User;
import com.vti.vtira59backend.modal.request.CreateProductRequest;
import com.vti.vtira59backend.modal.request.CreateUserRequest;
import com.vti.vtira59backend.modal.request.UpdateProductRequest;
import com.vti.vtira59backend.modal.request.UpdateUserRequest;

import java.util.List;

public interface IUserService {
    List<User> getAll();

    User getById(int id);

    void create(CreateUserRequest request);

    User update(UpdateUserRequest request);

    void delete(int id);
}
