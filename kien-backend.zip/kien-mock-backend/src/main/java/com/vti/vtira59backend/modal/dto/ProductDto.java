package com.vti.vtira59backend.modal.dto;


import com.vti.vtira59backend.modal.entity.Status;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
public class ProductDto {

    private int id;

    private String productName;

    private Status status;

    private String description;

    private int startPrice;

    private Date startTime;

    private Date endTime;

    private int creatorId;

}
