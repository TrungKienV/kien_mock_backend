package com.vti.vtira59backend.repository;

import com.vti.vtira59backend.modal.entity.Product;
import com.vti.vtira59backend.modal.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
}
