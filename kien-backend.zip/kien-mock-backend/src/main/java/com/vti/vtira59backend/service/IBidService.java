package com.vti.vtira59backend.service;

import com.vti.vtira59backend.modal.dto.BidDto;
import com.vti.vtira59backend.modal.entity.Bid;
import com.vti.vtira59backend.modal.request.CreateBidRequest;
import com.vti.vtira59backend.modal.request.UpdateBidRequest;

import java.util.List;
import java.util.Optional;

public interface IBidService {
    List<BidDto> getBidByProductId(int id);

    void createBid(CreateBidRequest form);

    void deleteBid(int id);

    void updateBid(UpdateBidRequest form);
}
