package com.vti.vtira59backend.modal.request;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UpdateOrderRequest {
    private int id;
    private int finalPrice;
    private int productId;
    private int buyerId;
}
