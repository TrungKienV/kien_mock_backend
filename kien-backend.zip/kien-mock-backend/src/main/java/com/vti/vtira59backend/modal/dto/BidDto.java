package com.vti.vtira59backend.modal.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BidDto {
    private int id;
    private int bidPrice;
    private int buyerId;

}
