package com.vti.vtira59backend.modal.request;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
public class UpdateBidRequest {
    private int id;
    private int bidPrice;
    private Date bidTime;
    private int buyerId;
    private int productId;
}
