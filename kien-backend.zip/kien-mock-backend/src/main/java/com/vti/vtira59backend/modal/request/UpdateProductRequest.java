package com.vti.vtira59backend.modal.request;

import com.vti.vtira59backend.modal.entity.Status;
import lombok.Data;

import java.util.Date;

@Data
public class UpdateProductRequest {
    private int id;

    private String productName;

    private Status status;

    private String description;

    private int startPrice;

    private Date startTime;

    private Date endTime;

    private int creatorId;

}
