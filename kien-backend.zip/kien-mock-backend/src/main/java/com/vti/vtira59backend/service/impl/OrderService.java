package com.vti.vtira59backend.service.impl;

import com.vti.vtira59backend.modal.dto.BidDto;
import com.vti.vtira59backend.modal.dto.OrderDto;
import com.vti.vtira59backend.modal.entity.Bid;
import com.vti.vtira59backend.modal.entity.Order;
import com.vti.vtira59backend.modal.request.CreateBidRequest;
import com.vti.vtira59backend.modal.request.CreateOrderRequest;
import com.vti.vtira59backend.modal.request.UpdateOrderRequest;
import com.vti.vtira59backend.repository.OrderRepository;
import com.vti.vtira59backend.service.IOrderService;
import org.modelmapper.ModelMapper;
import org.modelmapper.PropertyMap;
import org.modelmapper.TypeMap;
import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService implements IOrderService {
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<OrderDto> getBidByBuyerId(int id) {
        List<Order> orders =
//                orderRepository.findAll();
                orderRepository.findByBuyerId(id);
        List<OrderDto> orderDtos = modelMapper.map(orders, new TypeToken<List<OrderDto>>() {
        }.getType());
        return orderDtos;
    }

    @Override
    public void createOrder(CreateOrderRequest form) {
        TypeMap<CreateOrderRequest,Order> typeMap = modelMapper.getTypeMap(CreateOrderRequest.class, Order.class);
        if(typeMap == null){
            modelMapper.addMappings(new PropertyMap<CreateBidRequest, Bid>() {
                @Override
                protected void configure() {
                    skip(destination.getId());
                }
            });

            Order order = modelMapper.map(form, Order.class);
            orderRepository.save(order);
        }
    }

    @Override
    public void updateOrder(UpdateOrderRequest form) {
        Order order = modelMapper.map(form, Order.class);
        orderRepository.save(order);
    }

    @Override
    public void deleteOrder(int id) {
        orderRepository.deleteById(id);
    }
}
