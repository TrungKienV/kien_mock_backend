package com.vti.vtira59backend.modal.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderDto {
    private int id;
    private int finalPrice;
    private int productId;
    private int buyerId;
}
