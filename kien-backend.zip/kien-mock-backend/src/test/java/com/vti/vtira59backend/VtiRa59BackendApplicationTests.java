package com.vti.vtira59backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VtiRa59BackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
